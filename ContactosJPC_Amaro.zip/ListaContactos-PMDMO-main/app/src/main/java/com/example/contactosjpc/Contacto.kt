package com.example.contactosjpc

data class Contacto(val nombre: String, val telefono: String, val image: Int) {

}
